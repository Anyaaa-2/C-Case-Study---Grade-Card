The functions are placed in functions.c
main.c contains switch case
function_def.h is the header file
project.mk is the makefile which can generate the exe file "a.exe" and links all the function files to the main file